import React from 'react'; 

const Menuitems = [
    {
        id:'c1',
        menuname:'All Courses', 
        menuclass:'menu1',
    },
    {
        id:'c1',
        menuname:'Upload Project', 
        menuclass:'menu2',
    },
    {
        id:'c1',
        menuname:'Project Rank', 
        menuclass:'menu3',
    },
    {
        id:'c1',
        menuname:'Check Your CV', 
        menuclass:'menu4',
    },
    {
        id:'c1',
        menuname:'Refer & Earn', 
        menuclass:'menu4',
    }, 
];

export default Menuitems;
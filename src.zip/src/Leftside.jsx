import React from 'react';
import { Link } from 'react-router-dom';
import Menuitems from './Menuitems';
import useStartTour from './Function'; 
import Msgdata from './Msgdata'; 

const Leftside = (props) => {
    const addData = useStartTour();
    return( 
        <>
           <div className={Msgdata[addData.count].leftmenu}> 
                     {Menuitems.map((menuItems) => {
                        return (
                            <MenuLink 
                                key={menuItems.id}
                                menuname={menuItems.menuname} 
                                menuclass={menuItems.menuclass}
                            />
                        );
                    })}
                />
           </div> 
        </>
    );
}
const MenuLink = (props) => {
    return(
        <>
        <Link to="/" className={props.menuclass}>{props.menuname}</Link> 
        </>
    );
}
export {Leftside,MenuLink} ;
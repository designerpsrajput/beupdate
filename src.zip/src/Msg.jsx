import React, { useEffect, useRef, useState } from 'react';  
import { Link } from 'react-router-dom'; 
import Innermsg from './Innermsg';
import useStartTour from './Function'; 
import Msgdata from './Msgdata'; 


const Msg = (props) => {    
    const addData = useStartTour();  
    return (
    <div className={Msgdata[addData.count].mainClass}>
        <div className="z-index">
            <Innermsg  
                key={Msgdata[addData.count].id}
                imgsrc={Msgdata[addData.count].imgsrc}
                cname={Msgdata[addData.count].cname}
                msg={Msgdata[addData.count].msg} 
            />
            <p className={addData.Gethide}>You have Got <span>{addData.Getreward}</span>  Reaward Point.</p>
            <Link to="/" onClick={addData.handleStart}  className="btn btn-info">{Msgdata[addData.count].linktxt}</Link> 
           
        </div>
    </div>
    ) 
} 
export default Msg;
import React from 'react';
 import useStartTour from './Function'; 
import Msgdata from './Msgdata'; 
import Msg from './Msg';

const Rewardscount = () => {  
    const addData = useStartTour();
    return (
        <small id="Recount" className="Recount">{addData.Getreward}</small>
    );
}

export default Rewardscount;
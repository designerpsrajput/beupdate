import React from 'react';
import {Link} from 'react-router-dom';
import {LeaderBoard,Rewards,Profile} from './Icons';  
import useStartTour from './Function'; 
import Msgdata from './Msgdata'; 
import Rewardscount from './Rewardscount'; 

const Header = ()=> {
    const addData = useStartTour(); 
    return(
        <>
            <header>
                <div className="topLinks">
                    <Link to="/" className={Msgdata[addData.count].Zinedx}><LeaderBoard /><span>Leadership Borad</span> <Rewardscount /></Link>
                    <Link to="/" id="rewardi"><Rewards /><span>Rewards</span></Link>
                    <Link to="/"><Profile /><span>My Profile</span></Link>
                </div>
            </header>
        </>
    );
}

export default Header;
import React from 'react'; 

const LeaderBoard = () => <i className="fas fa-file-alt"></i>
const Rewards = () => <i className="fa fa-trophy"></i>
const Profile = () => <i className="fa fa-user"></i>
const Chat = () => <i className="fas fa-comment-dots"></i>

export {LeaderBoard,Rewards,Profile,Chat} ;